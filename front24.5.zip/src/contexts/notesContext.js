import { createContext } from 'react';

const NotesContext = createContext(null);
export default NotesContext;
