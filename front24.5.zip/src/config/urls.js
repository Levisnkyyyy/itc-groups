const CONFIG_URLS = {
  base: 'http://localhost:4000',
};

export default CONFIG_URLS;
